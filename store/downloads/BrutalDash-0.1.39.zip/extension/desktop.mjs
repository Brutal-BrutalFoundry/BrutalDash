// node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message, kind) {
    super(message);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder3 = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value: value2 } = await reader.read();
      if (done)
        break;
      buffered += decoder3.decode(value2, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder3.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message) {
    const chunk = this.encoder.encode(`${JSON.stringify(message)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime11 = globalThis.Deno;
  if (!runtime11) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime11.stdin.readable,
    writable: runtime11.stdout.writable,
    exit: (code) => runtime11.exit(code)
  };
}

// node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message) {
  return message.encoding === "json" ? message.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message) {
  if (typeof message === "string")
    return { encoding: "text", data: message };
  if (message instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message) };
  if (message.encoding === "binary")
    return { encoding: "binary", data: toBase64(message.data) };
  return message;
}
function fromWire(message) {
  if (message.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message.data) };
  return message;
}

// node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// node_modules/@bridgething/extension/dist/runtime.js
function describe(value2) {
  if (typeof value2 === "string")
    return value2;
  if (value2 instanceof Error)
    return value2.stack ?? `${value2.name}: ${value2.message}`;
  try {
    return JSON.stringify(value2) ?? String(value2);
  } catch {
    return String(value2);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime11) {
    this.id = id;
    this.runtime = runtime11;
  }
  send(message) {
    this.runtime.forward(this.id, message);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message) {
    this.forward(void 0, message);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value2) => value2 === null ? void 0 : value2),
    set: (key, value2) => this.request((id) => ({ t: "kv.set", id, key, value: value2 })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value2) => value2 ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value2) => String(value2))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message) {
    const wire = intoWire(message);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message = this.parse(line);
        if (!message)
          continue;
        if (message.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message) {
    switch (message.t) {
      case "hello": {
        this.helloApi = message.api;
        this.helloWebapp = message.webapp;
        this.helloDataDir = message.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message.device);
        device.name = message.name;
        device.config = { ...message.config };
        device.active = message.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message.device);
        device.active = message.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message.device);
        const forwarded = this.guard(() => fromWire(message.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message.device);
        const next = { ...device.config };
        if (message.value === null)
          delete next[message.key];
        else
          next[message.key] = message.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message.key, message.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message.id);
        if (!waiting)
          return;
        this.pending.delete(message.id);
        if (message.ok)
          waiting.resolve(message.value);
        else
          waiting.reject(new ExtensionError(message.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message) {
    this.writer.write(message).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// extension/foreground.ts
var PROCESS_QUERY_LIMITED_INFORMATION = 4096;
var TEXT_BUFFER_CHARS = 1024;
var MONITOR_DEFAULTTONEAREST = 2;
var user32;
var kernel32;
function runtime() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function isPointer(value2) {
  return value2 !== null && value2 !== void 0;
}
function text2(bytes, characters) {
  const limit = Math.min(characters === void 0 ? bytes.byteLength / 2 : characters, bytes.byteLength / 2);
  return new TextDecoder("utf-16le").decode(bytes.subarray(0, limit * 2)).replace(/\0.*$/, "").trim();
}
function nameFromPath(path) {
  return path.split(/[\\/]/).pop()?.replace(/\.exe$/i, "").trim() || "";
}
function apis() {
  if (user32 !== void 0 && kernel32 !== void 0) return user32 && kernel32 ? { user32, kernel32 } : null;
  const deno = runtime();
  if (!deno) {
    user32 = null;
    kernel32 = null;
    return null;
  }
  try {
    user32 = deno.dlopen("user32.dll", {
      GetForegroundWindow: { parameters: [], result: "pointer" },
      GetWindowThreadProcessId: { parameters: ["pointer", "buffer"], result: "u32" },
      GetWindowTextW: { parameters: ["pointer", "buffer", "i32"], result: "i32" },
      GetWindowRect: { parameters: ["pointer", "buffer"], result: "i32" },
      MonitorFromWindow: { parameters: ["pointer", "u32"], result: "pointer" },
      GetMonitorInfoW: { parameters: ["pointer", "buffer"], result: "i32" }
    });
    kernel32 = deno.dlopen("kernel32.dll", {
      OpenProcess: { parameters: ["u32", "u8", "u32"], result: "pointer" },
      QueryFullProcessImageNameW: { parameters: ["pointer", "u32", "buffer", "buffer"], result: "u8" },
      CloseHandle: { parameters: ["pointer"], result: "u8" }
    });
  } catch {
    user32 = null;
    kernel32 = null;
  }
  return user32 && kernel32 ? { user32, kernel32 } : null;
}
function isFullscreenWindow(api5, window) {
  const windowRect = new Uint8Array(16);
  if (!api5.symbols.GetWindowRect(window, windowRect)) return false;
  const monitor = api5.symbols.MonitorFromWindow(window, MONITOR_DEFAULTTONEAREST);
  if (!isPointer(monitor)) return false;
  const monitorInfo = new Uint8Array(40);
  new DataView(monitorInfo.buffer).setUint32(0, monitorInfo.byteLength, true);
  if (!api5.symbols.GetMonitorInfoW(monitor, monitorInfo)) return false;
  const windowValues = new Int32Array(windowRect.buffer);
  const monitorValues = new Int32Array(monitorInfo.buffer, 4, 4);
  const tolerance = 8;
  return Math.abs(windowValues[0] - monitorValues[0]) <= tolerance && Math.abs(windowValues[1] - monitorValues[1]) <= tolerance && Math.abs(windowValues[2] - monitorValues[2]) <= tolerance && Math.abs(windowValues[3] - monitorValues[3]) <= tolerance;
}
function readForegroundApp() {
  try {
    const api5 = apis();
    if (!api5) return null;
    const window = api5.user32.symbols.GetForegroundWindow();
    if (!isPointer(window)) return null;
    const processId = new Uint32Array(1);
    api5.user32.symbols.GetWindowThreadProcessId(window, processId);
    const pid = processId[0];
    if (!pid) return null;
    const titleBuffer = new Uint8Array(TEXT_BUFFER_CHARS * 2);
    const titleLength = api5.user32.symbols.GetWindowTextW(window, titleBuffer, TEXT_BUFFER_CHARS);
    const process = api5.kernel32.symbols.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
    if (!isPointer(process)) return null;
    try {
      const pathBuffer = new Uint8Array(TEXT_BUFFER_CHARS * 2);
      const pathLength = new Uint32Array([TEXT_BUFFER_CHARS - 1]);
      if (!api5.kernel32.symbols.QueryFullProcessImageNameW(process, 0, pathBuffer, pathLength)) return null;
      const path = text2(pathBuffer, pathLength[0]);
      const name = nameFromPath(path);
      if (!name) return null;
      return { pid, name, path, title: text2(titleBuffer, Math.max(0, titleLength)), fullscreen: isFullscreenWindow(api5.user32, window) };
    } finally {
      api5.kernel32.symbols.CloseHandle(process);
    }
  } catch {
    return null;
  }
}

// extension/game.ts
var excludedForeground = /^(explorer|chrome|msedge|firefox|discord|code|codex|chatgpt|bridgething|steam|steamwebhelper|epicgameslauncher|goggalaxy|spotify|applicationframehost|searchhost|startmenuexperiencehost|shellexperiencehost|textinputhost|systemsettings|taskmgr|powershell|pwsh|cmd|conhost|windowsterminal|snippingtool|screenclippinghost|hwinfo64|presentmon|nvidiaapp|nvcontainer|radeonsoftware|msiafterburner|rtss)$/i;
function normalized(value2) {
  return value2.trim().split(/[\\/]/).pop()?.replace(/\.exe$/i, "").toLowerCase() || "";
}
function processFileName(app) {
  const executable = app.path.split(/[\\/]/).pop() || app.name;
  return /\.exe$/i.test(executable) ? executable : `${executable}.exe`;
}
function friendlyAppName(app) {
  const title = app.title.replace(/\s[-—|].*$/, "").trim();
  return (title || app.name.replace(/[-_]/g, " ")).replace(/([a-z])([A-Z])/g, "$1 $2").replace(/64$/, "").trim() || app.name;
}
function preferenceHas(entries, app) {
  const expected = normalized(processFileName(app));
  return (entries || []).some((entry) => normalized(entry) === expected);
}
function gameCandidate(app, preferences) {
  if (!app || preferenceHas(preferences.gameExclude, app)) return null;
  const name = normalized(app.name);
  const included = preferenceHas(preferences.gameInclude, app);
  if (!included && excludedForeground.test(name)) return null;
  const known = /^(aces|aces_be|projectzomboid64)$/i.test(name);
  const likelyPath = /\\(steamapps\\common|Epic Games|XboxGames|GOG Galaxy\\Games)\\/i.test(app.path);
  const likelyName = /(game|shipping|win64|dx11|dx12|client)$/i.test(name);
  return included || known || likelyPath || likelyName || app.fullscreen ? processFileName(app) : null;
}
function fpsCaptureTarget(app, preferences, retainedGame, now, retentionMs) {
  const liveProcessName = gameCandidate(app, preferences);
  if (liveProcessName) return { liveProcessName, sensorProcessName: liveProcessName };
  if (retainedGame && now - retainedGame.seenAt <= retentionMs) {
    return { liveProcessName: null, sensorProcessName: retainedGame.processName };
  }
  return { liveProcessName: null, sensorProcessName: null };
}
function detectedGame(app, hasPresentMonReadings, preferences) {
  if (!app || preferenceHas(preferences.gameExclude, app)) return null;
  const name = normalized(app.name);
  const included = preferenceHas(preferences.gameInclude, app);
  if (!included && excludedForeground.test(name)) return null;
  const knownGame = (/* @__PURE__ */ new Map([
    ["aces", "War Thunder"],
    ["aces_be", "War Thunder"],
    ["projectzomboid64", "Project Zomboid"]
  ])).get(name);
  if (knownGame) return knownGame;
  const likelyGamePath = /\\(steamapps\\common|Epic Games|XboxGames|GOG Galaxy\\Games)\\/i.test(app.path);
  const likelyGameName = /(game|shipping|win64|dx11|dx12|client)$/i.test(name);
  if (!included && !likelyGamePath && !likelyGameName && !(hasPresentMonReadings && app.fullscreen)) return null;
  return friendlyAppName(app);
}
function foregroundPacket(app) {
  return app ? { processName: processFileName(app), displayName: friendlyAppName(app), fullscreen: app.fullscreen } : null;
}

// extension/disk.ts
var PDH_SUCCESS = 0;
var PDH_MORE_DATA = 2147485650;
var PDH_FMT_DOUBLE = 512;
var COUNTER_VALUE_ITEM_BYTES_64 = 24;
var COUNTER_VALUE_OFFSET_64 = 16;
var MIB = 1024 ** 2;
var pdh;
var counters;
function runtime2() {
  const candidate = globalThis.Deno;
  if (!candidate || candidate.build.os !== "windows") return null;
  return candidate.build.arch === "x86_64" || candidate.build.arch === "aarch64" ? candidate : null;
}
function utf16(value2) {
  const bytes = new Uint8Array((value2.length + 1) * 2);
  const view = new DataView(bytes.buffer);
  for (let index = 0; index < value2.length; index += 1) view.setUint16(index * 2, value2.charCodeAt(index), true);
  return bytes;
}
function api() {
  if (pdh !== void 0) return pdh;
  const deno = runtime2();
  if (!deno) return pdh = null;
  try {
    pdh = deno.dlopen("pdh.dll", {
      PdhOpenQueryW: { parameters: ["pointer", "u64", "buffer"], result: "u32" },
      PdhAddEnglishCounterW: { parameters: ["pointer", "buffer", "u64", "buffer"], result: "u32" },
      PdhCollectQueryData: { parameters: ["pointer"], result: "u32" },
      PdhGetFormattedCounterArrayW: { parameters: ["pointer", "u32", "buffer", "buffer", "pointer"], result: "u32" },
      PdhCloseQuery: { parameters: ["pointer"], result: "u32" }
    });
  } catch {
    pdh = null;
  }
  return pdh;
}
function pointer(runtime11, buffer) {
  const value2 = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength).getBigUint64(0, true);
  return value2 ? runtime11.UnsafePointer.create(value2) : null;
}
function addCounter(runtime11, api5, query, path) {
  const output = new Uint8Array(8);
  if (api5.symbols.PdhAddEnglishCounterW(query, utf16(path), 0n, output) !== PDH_SUCCESS) return null;
  return pointer(runtime11, output);
}
function openCounters() {
  if (counters !== void 0) return counters;
  const deno = runtime2();
  const library = api();
  if (!deno || !library) return counters = null;
  try {
    const output = new Uint8Array(8);
    if (library.symbols.PdhOpenQueryW(null, 0n, output) !== PDH_SUCCESS) return counters = null;
    const query = pointer(deno, output);
    if (!query) return counters = null;
    const read = addCounter(deno, library, query, "\\PhysicalDisk(_Total)\\Disk Read Bytes/sec");
    const write = addCounter(deno, library, query, "\\PhysicalDisk(_Total)\\Disk Write Bytes/sec");
    if (!read || !write) {
      library.symbols.PdhCloseQuery(query);
      return counters = null;
    }
    library.symbols.PdhCollectQueryData(query);
    return counters = { query, read, write };
  } catch {
    return counters = null;
  }
}
function value(deno, library, counter) {
  const size2 = new Uint8Array(4);
  const count = new Uint8Array(4);
  const first = library.symbols.PdhGetFormattedCounterArrayW(counter, PDH_FMT_DOUBLE, size2, count, null);
  if (first !== PDH_MORE_DATA && first !== PDH_SUCCESS) return null;
  const bytes = new DataView(size2.buffer).getUint32(0, true);
  const entries = new DataView(count.buffer).getUint32(0, true);
  if (!bytes || !entries || bytes < entries * COUNTER_VALUE_ITEM_BYTES_64) return null;
  const output = new Uint8Array(bytes);
  if (library.symbols.PdhGetFormattedCounterArrayW(counter, PDH_FMT_DOUBLE, size2, count, deno.UnsafePointer.of(output)) !== PDH_SUCCESS) return null;
  const view = new DataView(output.buffer, output.byteOffset, output.byteLength);
  const result = view.getFloat64(COUNTER_VALUE_OFFSET_64, true);
  return Number.isFinite(result) && result >= 0 ? result : null;
}
function readDiskIoRates() {
  try {
    const deno = runtime2();
    const library = api();
    const active = openCounters();
    if (!deno || !library || !active || library.symbols.PdhCollectQueryData(active.query) !== PDH_SUCCESS) return null;
    return {
      readMbPerSec: (() => {
        const bytes = value(deno, library, active.read);
        return bytes === null ? null : bytes / MIB;
      })(),
      writeMbPerSec: (() => {
        const bytes = value(deno, library, active.write);
        return bytes === null ? null : bytes / MIB;
      })()
    };
  } catch {
    return null;
  }
}

// extension/hwinfo.ts
var FILE_MAP_READ = 4;
var SYNCHRONIZE = 1048576;
var WAIT_OBJECT_0 = 0;
var WAIT_ABANDONED = 128;
var MUTEX_TIMEOUT_MS = 25;
var HEADER_BYTES = 48;
var MAX_SENSORS = 4096;
var MAX_READINGS = 16384;
var MAX_MAPPING_BYTES = 16 * 1024 * 1024;
var SENSOR_NAME_BYTES = 128;
var UNIT_BYTES = 16;
var decoder = new TextDecoder();
var kernel322;
function runtime3() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function utf162(value2) {
  const bytes = new Uint8Array((value2.length + 1) * 2);
  const view = new DataView(bytes.buffer);
  for (let index = 0; index < value2.length; index += 1) view.setUint16(index * 2, value2.charCodeAt(index), true);
  return bytes;
}
function readText(bytes, offset, length) {
  const end = Math.min(offset + length, bytes.length);
  let zero = offset;
  while (zero < end && bytes[zero] !== 0) zero += 1;
  return decoder.decode(bytes.subarray(offset, zero)).trim();
}
function isPointer2(value2) {
  return value2 !== null && value2 !== void 0;
}
function checkedEnd(offset, size2, count) {
  if (![offset, size2, count].every(Number.isSafeInteger) || offset < HEADER_BYTES || size2 <= 0 || count < 0) return null;
  const end = offset + size2 * count;
  return Number.isSafeInteger(end) && end <= MAX_MAPPING_BYTES ? end : null;
}
function kernel() {
  if (kernel322 !== void 0) return kernel322;
  const deno = runtime3();
  if (!deno) return kernel322 = null;
  try {
    kernel322 = deno.dlopen("kernel32.dll", {
      OpenFileMappingW: { parameters: ["u32", "u8", "buffer"], result: "pointer" },
      MapViewOfFile: { parameters: ["pointer", "u32", "u32", "u32", "usize"], result: "pointer" },
      UnmapViewOfFile: { parameters: ["pointer"], result: "u8" },
      CloseHandle: { parameters: ["pointer"], result: "u8" },
      OpenMutexW: { parameters: ["u32", "u8", "buffer"], result: "pointer" },
      WaitForSingleObject: { parameters: ["pointer", "u32"], result: "u32" },
      ReleaseMutex: { parameters: ["pointer"], result: "u8" }
    });
  } catch {
    kernel322 = null;
  }
  return kernel322;
}
function snapshot() {
  const deno = runtime3();
  const api5 = kernel();
  if (!deno || !api5) return null;
  const mapping = api5.symbols.OpenFileMappingW(FILE_MAP_READ, 0, utf162("Global\\HWiNFO_SENS_SM2"));
  if (!isPointer2(mapping)) return null;
  const mutex = api5.symbols.OpenMutexW(SYNCHRONIZE, 0, utf162("Global\\HWiNFO_SM2_MUTEX"));
  const view = api5.symbols.MapViewOfFile(mapping, FILE_MAP_READ, 0, 0, 0);
  let ownsMutex = false;
  try {
    if (!isPointer2(view)) return null;
    if (isPointer2(mutex)) {
      const wait = api5.symbols.WaitForSingleObject(mutex, MUTEX_TIMEOUT_MS);
      if (wait !== WAIT_OBJECT_0 && wait !== WAIT_ABANDONED) return null;
      ownsMutex = true;
    }
    const pointerView = new deno.UnsafePointerView(view);
    const header = pointerView.getArrayBuffer(HEADER_BYTES);
    const fields = new DataView(header);
    const signature = String.fromCharCode(...new Uint8Array(header, 0, 4));
    const sensorEnd = checkedEnd(fields.getUint32(20, true), fields.getUint32(24, true), fields.getUint32(28, true));
    const readingEnd = checkedEnd(fields.getUint32(32, true), fields.getUint32(36, true), fields.getUint32(40, true));
    if (signature !== "HWiS" || !sensorEnd || !readingEnd) return null;
    const mapped = new Uint8Array(pointerView.getArrayBuffer(Math.max(HEADER_BYTES, sensorEnd, readingEnd)));
    return mapped.slice().buffer;
  } finally {
    if (ownsMutex && isPointer2(mutex)) api5.symbols.ReleaseMutex(mutex);
    if (isPointer2(mutex)) api5.symbols.CloseHandle(mutex);
    if (isPointer2(view)) api5.symbols.UnmapViewOfFile(view);
    api5.symbols.CloseHandle(mapping);
  }
}
function parseHwInfoSharedMemory(buffer) {
  try {
    const fields = new DataView(buffer);
    const bytes = new Uint8Array(buffer);
    const signature = String.fromCharCode(...bytes.subarray(0, 4));
    if (signature !== "HWiS") return [];
    const sensorOffset = fields.getUint32(20, true);
    const sensorSize = fields.getUint32(24, true);
    const sensorCount = fields.getUint32(28, true);
    const readingOffset = fields.getUint32(32, true);
    const readingSize = fields.getUint32(36, true);
    const readingCount = fields.getUint32(40, true);
    const sensorEnd = checkedEnd(sensorOffset, sensorSize, sensorCount);
    const readingEnd = checkedEnd(readingOffset, readingSize, readingCount);
    if (sensorCount > MAX_SENSORS || readingCount > MAX_READINGS || sensorSize < 264 || readingSize < 316 || !sensorEnd || !readingEnd || sensorEnd > buffer.byteLength || readingEnd > buffer.byteLength) return [];
    const parents = Array.from({ length: sensorCount }, (_, index) => {
      const offset = sensorOffset + sensorSize * index;
      return {
        original: readText(bytes, offset + 8, SENSOR_NAME_BYTES),
        custom: readText(bytes, offset + 8 + SENSOR_NAME_BYTES, SENSOR_NAME_BYTES)
      };
    });
    const sensors = [];
    for (let index = 0; index < readingCount; index += 1) {
      const offset = readingOffset + readingSize * index;
      const parent = parents[fields.getUint32(offset + 4, true)];
      const valueNow = fields.getFloat64(offset + 284, true);
      if (!parent || !Number.isFinite(valueNow)) continue;
      sensors.push({
        nameDefault: readText(bytes, offset + 12, SENSOR_NAME_BYTES),
        nameCustom: readText(bytes, offset + 12 + SENSOR_NAME_BYTES, SENSOR_NAME_BYTES),
        parentNameDefault: parent.original,
        parentNameCustom: parent.custom,
        unit: readText(bytes, offset + 12 + SENSOR_NAME_BYTES * 2, UNIT_BYTES),
        valueNow
      });
    }
    return sensors;
  } catch {
    return [];
  }
}
function readHwInfoSharedMemory() {
  const buffer = snapshot();
  return buffer ? parseHwInfoSharedMemory(buffer) : [];
}

// extension/native.ts
var MEMORY_STATUS_BYTES = 64;
var GIB = 1024 ** 3;
var kernel323;
var advapi32;
var previousCpu = null;
var processorName;
function runtime4() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function kernel2() {
  if (kernel323 !== void 0) return kernel323;
  const deno = runtime4();
  if (!deno) return kernel323 = null;
  try {
    kernel323 = deno.dlopen("kernel32.dll", {
      GetSystemTimes: { parameters: ["buffer", "buffer", "buffer"], result: "u8" },
      GlobalMemoryStatusEx: { parameters: ["buffer"], result: "u8" }
    });
  } catch {
    kernel323 = null;
  }
  return kernel323;
}
function registry() {
  if (advapi32 !== void 0) return advapi32;
  const deno = runtime4();
  if (!deno) return advapi32 = null;
  try {
    advapi32 = deno.dlopen("advapi32.dll", {
      RegOpenKeyExW: { parameters: ["pointer", "buffer", "u32", "u32", "buffer"], result: "i32" },
      RegQueryValueExW: { parameters: ["pointer", "buffer", "pointer", "buffer", "buffer", "buffer"], result: "i32" },
      RegCloseKey: { parameters: ["pointer"], result: "i32" }
    });
  } catch {
    advapi32 = null;
  }
  return advapi32;
}
function utf163(value2) {
  const bytes = new Uint8Array((value2.length + 1) * 2);
  const view = new DataView(bytes.buffer);
  for (let index = 0; index < value2.length; index += 1) view.setUint16(index * 2, value2.charCodeAt(index), true);
  return bytes;
}
function fileTime(buffer) {
  const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
  return view.getBigUint64(0, true);
}
function cpuPercent(api5) {
  const idle = new Uint8Array(8);
  const kernelTime = new Uint8Array(8);
  const user = new Uint8Array(8);
  if (!api5.symbols.GetSystemTimes(idle, kernelTime, user)) return null;
  const next = { idle: fileTime(idle), total: fileTime(kernelTime) + fileTime(user) };
  const previous2 = previousCpu;
  previousCpu = next;
  if (!previous2 || next.total <= previous2.total || next.idle < previous2.idle) return null;
  const totalDelta = next.total - previous2.total;
  const busyDelta = totalDelta - (next.idle - previous2.idle);
  return Math.max(0, Math.min(100, Number(busyDelta) / Number(totalDelta) * 100));
}
function memory(api5) {
  const status = new Uint8Array(MEMORY_STATUS_BYTES);
  new DataView(status.buffer).setUint32(0, MEMORY_STATUS_BYTES, true);
  if (!api5.symbols.GlobalMemoryStatusEx(status)) return null;
  const view = new DataView(status.buffer);
  const totalBytes = view.getBigUint64(8, true);
  const availableBytes = view.getBigUint64(16, true);
  if (!totalBytes || availableBytes > totalBytes) return null;
  const ramTotalGb = Number(totalBytes) / GIB;
  const ramUsedGb = Number(totalBytes - availableBytes) / GIB;
  return { ramUsedGb, ramTotalGb, ramPercent: ramUsedGb / ramTotalGb * 100 };
}
function readProcessorName() {
  if (processorName !== void 0) return processorName;
  const deno = runtime4();
  const api5 = registry();
  if (!deno || !api5) return processorName = null;
  try {
    const result = new Uint8Array(8);
    const machine = deno.UnsafePointer.create(0x80000002n);
    const access = 131097;
    if (api5.symbols.RegOpenKeyExW(machine, utf163("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"), 0, access, result) !== 0) return processorName = null;
    const keyValue = new DataView(result.buffer).getBigUint64(0, true);
    if (!keyValue) return processorName = null;
    const key = deno.UnsafePointer.create(keyValue);
    try {
      const kind = new Uint8Array(4);
      const data = new Uint8Array(512);
      const size2 = new Uint8Array(4);
      new DataView(size2.buffer).setUint32(0, data.byteLength, true);
      if (api5.symbols.RegQueryValueExW(key, utf163("ProcessorNameString"), null, kind, data, size2) !== 0) return processorName = null;
      const length = Math.min(new DataView(size2.buffer).getUint32(0, true), data.byteLength);
      const name = new TextDecoder("utf-16le").decode(data.subarray(0, length)).replace(/\0.*$/, "").trim();
      return processorName = name || null;
    } finally {
      api5.symbols.RegCloseKey(key);
    }
  } catch {
    return processorName = null;
  }
}
function readNativeSystemMetrics() {
  try {
    const api5 = kernel2();
    if (!api5) return null;
    const ram = memory(api5);
    return {
      cpuPercent: cpuPercent(api5),
      ramUsedGb: ram?.ramUsedGb ?? null,
      ramTotalGb: ram?.ramTotalGb ?? null,
      ramPercent: ram?.ramPercent ?? null
    };
  } catch {
    return null;
  }
}

// extension/network.ts
var ERROR_INSUFFICIENT_BUFFER = 122;
var MIB_IFROW_BYTES = 860;
var MIB_IFROW_OFFSET = 4;
var IF_INDEX_OFFSET = 512;
var IF_TYPE_OFFSET = 516;
var IF_OPER_STATUS_OFFSET = 544;
var IF_IN_OCTETS_OFFSET = 552;
var IF_OUT_OCTETS_OFFSET = 576;
var ACTIVE_INTERFACE_STATUSES = /* @__PURE__ */ new Set([5, 6]);
var EXCLUDED_INTERFACE_TYPES = /* @__PURE__ */ new Set([24, 131, 144]);
var OCTET_COUNTER_MODULUS = 2 ** 32;
var ipHelper;
var previous = /* @__PURE__ */ new Map();
var previousAt = 0;
function runtime5() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function api2() {
  if (ipHelper !== void 0) return ipHelper;
  const deno = runtime5();
  if (!deno) return ipHelper = null;
  try {
    ipHelper = deno.dlopen("iphlpapi.dll", {
      GetIfTable: { parameters: ["buffer", "buffer", "u8"], result: "u32" }
    });
  } catch {
    ipHelper = null;
  }
  return ipHelper;
}
function interfaceCounters(helper) {
  const seed = new Uint8Array(MIB_IFROW_OFFSET);
  const required = new Uint8Array(4);
  new DataView(required.buffer).setUint32(0, seed.byteLength, true);
  const initial = helper.symbols.GetIfTable(seed, required, 0);
  const bytes = new DataView(required.buffer).getUint32(0, true);
  if (initial !== ERROR_INSUFFICIENT_BUFFER && initial !== 0 || bytes < MIB_IFROW_OFFSET) return null;
  const table = new Uint8Array(bytes);
  if (helper.symbols.GetIfTable(table, required, 0) !== 0) return null;
  const view = new DataView(table.buffer, table.byteOffset, table.byteLength);
  const count = view.getUint32(0, true);
  if (MIB_IFROW_OFFSET + count * MIB_IFROW_BYTES > table.byteLength) return null;
  const result = /* @__PURE__ */ new Map();
  for (let entry = 0; entry < count; entry += 1) {
    const row = MIB_IFROW_OFFSET + entry * MIB_IFROW_BYTES;
    const type = view.getUint32(row + IF_TYPE_OFFSET, true);
    const status = view.getUint32(row + IF_OPER_STATUS_OFFSET, true);
    if (!ACTIVE_INTERFACE_STATUSES.has(status) || EXCLUDED_INTERFACE_TYPES.has(type)) continue;
    result.set(view.getUint32(row + IF_INDEX_OFFSET, true), {
      received: view.getUint32(row + IF_IN_OCTETS_OFFSET, true),
      sent: view.getUint32(row + IF_OUT_OCTETS_OFFSET, true)
    });
  }
  return result;
}
function delta(current, before) {
  return current >= before ? current - before : current + OCTET_COUNTER_MODULUS - before;
}
function readNetworkRates(now = Date.now()) {
  try {
    const helper = api2();
    if (!helper) return null;
    const current = interfaceCounters(helper);
    if (!current) return null;
    const elapsedSeconds = (now - previousAt) / 1e3;
    let receivedDelta = 0;
    let sentDelta = 0;
    let matched = 0;
    if (previousAt > 0 && elapsedSeconds > 0) {
      for (const [index, sample] of current) {
        const before = previous.get(index);
        if (!before) continue;
        matched += 1;
        receivedDelta += delta(sample.received, before.received);
        sentDelta += delta(sample.sent, before.sent);
      }
    }
    previous = current;
    previousAt = now;
    if (!matched) return { downKbps: 0, upKbps: 0 };
    return {
      downKbps: receivedDelta / elapsedSeconds / 1024,
      upKbps: sentDelta / elapsedSeconds / 1024
    };
  } catch {
    return null;
  }
}

// extension/nvidia.ts
var NVML_SUCCESS = 0;
var NVML_ERROR_ALREADY_INITIALIZED = 5;
var NVML_TEMPERATURE_GPU = 0;
var NVML_CLOCK_GRAPHICS = 0;
var GIB2 = 1024 ** 3;
var nvml;
var initialized = false;
function runtime6() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function api3() {
  if (nvml !== void 0) return nvml;
  const deno = runtime6();
  if (!deno) return nvml = null;
  try {
    nvml = deno.dlopen("nvml.dll", {
      nvmlInit_v2: { parameters: [], result: "u32" },
      nvmlDeviceGetCount_v2: { parameters: ["buffer"], result: "u32" },
      nvmlDeviceGetHandleByIndex_v2: { parameters: ["u32", "buffer"], result: "u32" },
      nvmlDeviceGetName: { parameters: ["pointer", "buffer", "u32"], result: "u32" },
      nvmlDeviceGetUtilizationRates: { parameters: ["pointer", "buffer"], result: "u32" },
      nvmlDeviceGetTemperature: { parameters: ["pointer", "u32", "buffer"], result: "u32" },
      nvmlDeviceGetClockInfo: { parameters: ["pointer", "u32", "buffer"], result: "u32" },
      nvmlDeviceGetPowerUsage: { parameters: ["pointer", "buffer"], result: "u32" },
      nvmlDeviceGetMemoryInfo: { parameters: ["pointer", "buffer"], result: "u32" }
    });
  } catch {
    nvml = null;
  }
  return nvml;
}
function u32(buffer, offset = 0) {
  return new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength).getUint32(offset, true);
}
function optionalU32(read) {
  const output = new Uint8Array(4);
  return read(output) === NVML_SUCCESS ? u32(output) : null;
}
function openHandle(runtime11, api5, index) {
  const raw = new Uint8Array(8);
  if (api5.symbols.nvmlDeviceGetHandleByIndex_v2(index, raw) !== NVML_SUCCESS) return null;
  const value2 = new DataView(raw.buffer).getBigUint64(0, true);
  return value2 ? runtime11.UnsafePointer.create(value2) : null;
}
function readDevice(api5, handle) {
  const nameBuffer = new Uint8Array(96);
  if (api5.symbols.nvmlDeviceGetName(handle, nameBuffer, nameBuffer.byteLength) !== NVML_SUCCESS) return null;
  const name = new TextDecoder().decode(nameBuffer).split("\0")[0].trim();
  if (!name) return null;
  const utilization = new Uint8Array(8);
  const usagePercent = api5.symbols.nvmlDeviceGetUtilizationRates(handle, utilization) === NVML_SUCCESS ? u32(utilization) : null;
  const memory2 = new Uint8Array(24);
  const hasMemory = api5.symbols.nvmlDeviceGetMemoryInfo(handle, memory2) === NVML_SUCCESS;
  return {
    name,
    usagePercent,
    temperatureC: optionalU32((output) => api5.symbols.nvmlDeviceGetTemperature(handle, NVML_TEMPERATURE_GPU, output)),
    clockMhz: optionalU32((output) => api5.symbols.nvmlDeviceGetClockInfo(handle, NVML_CLOCK_GRAPHICS, output)),
    powerWatts: (() => {
      const milliwatts = optionalU32((output) => api5.symbols.nvmlDeviceGetPowerUsage(handle, output));
      return milliwatts === null ? null : milliwatts / 1e3;
    })(),
    vramUsedGb: hasMemory ? Number(new DataView(memory2.buffer).getBigUint64(16, true)) / GIB2 : null,
    vramTotalGb: hasMemory ? Number(new DataView(memory2.buffer).getBigUint64(0, true)) / GIB2 : null
  };
}
function readNvidiaGpuMetrics() {
  try {
    const deno = runtime6();
    const driver = api3();
    if (!deno || !driver) return null;
    if (!initialized) {
      const status = driver.symbols.nvmlInit_v2();
      if (status !== NVML_SUCCESS && status !== NVML_ERROR_ALREADY_INITIALIZED) return null;
      initialized = true;
    }
    const countBuffer = new Uint8Array(4);
    if (driver.symbols.nvmlDeviceGetCount_v2(countBuffer) !== NVML_SUCCESS) return null;
    const count = u32(countBuffer);
    let selected = null;
    for (let index = 0; index < count; index += 1) {
      const handle = openHandle(deno, driver, index);
      if (!handle) continue;
      const metrics = readDevice(driver, handle);
      if (metrics && (selected?.usagePercent ?? -1) < (metrics.usagePercent ?? -1)) selected = metrics;
    }
    return selected;
  } catch {
    return null;
  }
}

// extension/presentmon.ts
var SAMPLE_WINDOW_MS = 2e3;
var ALT_TAB_GRACE_MS = 15e3;
var RETRY_DELAY_MS = 5e3;
var SESSION_NAME = "BrutalDash";
function runtime7() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function windowsPath(url) {
  const decoded = decodeURIComponent(url.pathname).replace(/^\/([A-Za-z]:)/, "$1");
  return decoded.replace(/\//g, "\\");
}
function executableCandidates() {
  return [
    // Installed BridgeThing extensions are extracted under extension/, so the
    // release bundle keeps its private PresentMon copy beside desktop.mjs.
    windowsPath(new URL("./vendor/presentmon/PresentMon.exe", import.meta.url)),
    windowsPath(new URL("../vendor/presentmon/PresentMon.exe", import.meta.url)),
    windowsPath(new URL("../public/vendor/presentmon/PresentMon.exe", import.meta.url)),
    windowsPath(new URL("../../public/vendor/presentmon/PresentMon.exe", import.meta.url))
  ];
}
function normalizeProcessName(value2) {
  const name = value2.trim().split(/[\\/]/).pop() || "";
  return name && /\.exe$/i.test(name) ? name : name ? `${name}.exe` : "";
}
function parseCsvRow(line) {
  const fields = [];
  let current = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"') {
      if (quoted && line[index + 1] === '"') {
        current += '"';
        index += 1;
      } else {
        quoted = !quoted;
      }
    } else if (character === "," && !quoted) {
      fields.push(current);
      current = "";
    } else {
      current += character;
    }
  }
  fields.push(current);
  return fields;
}
function percentile(values2, fraction) {
  const sorted = [...values2].sort((left, right) => left - right);
  const index = Math.min(sorted.length - 1, Math.max(0, Math.ceil(sorted.length * fraction) - 1));
  return sorted[index];
}
function summarizeFrameTimes(frameTimes) {
  const valid = frameTimes.filter((value2) => Number.isFinite(value2) && value2 >= 0.1 && value2 <= 1e3);
  if (valid.length < 5) return null;
  const frameTimeMs = valid.reduce((total, value2) => total + value2, 0) / valid.length;
  const slowFrameMs = percentile(valid, 0.99);
  return {
    fps: 1e3 / frameTimeMs,
    frameTimeMs,
    onePercentLowFps: 1e3 / slowFrameMs,
    sampleCount: valid.length
  };
}
async function readLines2(stream, consume) {
  const reader = stream.getReader();
  const decoder3 = new TextDecoder();
  let pending = "";
  try {
    while (true) {
      const { value: value2, done } = await reader.read();
      if (done) break;
      pending += decoder3.decode(value2, { stream: true });
      const lines = pending.split(/\r?\n/);
      pending = lines.pop() || "";
      for (const line of lines) consume(line);
    }
    pending += decoder3.decode();
    if (pending) consume(pending);
  } finally {
    reader.releaseLock();
  }
}
var PresentMonProvider = class {
  constructor(log) {
    this.log = log;
  }
  log;
  child = null;
  target = "";
  targetSeenAt = 0;
  retryAt = 0;
  generation = 0;
  samples = [];
  header = [];
  failureReported = false;
  updateTarget(processName, now = Date.now()) {
    const normalized2 = processName ? normalizeProcessName(processName) : "";
    if (normalized2) {
      this.targetSeenAt = now;
      if (this.target.toLowerCase() !== normalized2.toLowerCase()) {
        this.stopCapture();
        this.target = normalized2;
        this.failureReported = false;
      }
      if (!this.child && now >= this.retryAt) this.startCapture(normalized2);
      return;
    }
    if (this.child && now - this.targetSeenAt > ALT_TAB_GRACE_MS) this.stopCapture();
  }
  snapshot(now = Date.now()) {
    const cutoff = now - SAMPLE_WINDOW_MS;
    this.samples = this.samples.filter((sample) => sample.receivedAt >= cutoff);
    if (!this.samples.length) return null;
    const bySwapChain = /* @__PURE__ */ new Map();
    for (const sample of this.samples) {
      const group = bySwapChain.get(sample.swapChain) || [];
      group.push(sample);
      bySwapChain.set(sample.swapChain, group);
    }
    const primary = [...bySwapChain.values()].sort((left, right) => right.length - left.length)[0];
    return summarizeFrameTimes(primary.map((sample) => sample.frameTimeMs));
  }
  stop() {
    this.target = "";
    this.targetSeenAt = 0;
    this.stopCapture();
  }
  startCapture(target) {
    const deno = runtime7();
    if (!deno) return;
    const args = [
      "--process_name",
      target,
      "--output_stdout",
      "--v1_metrics",
      "--session_name",
      SESSION_NAME,
      "--stop_existing_session",
      "--no_console_stats",
      "--no_track_input"
    ];
    let child = null;
    let lastError = null;
    for (const executable of executableCandidates()) {
      try {
        child = new deno.Command(executable, { args, stdout: "piped", stderr: "piped" }).spawn();
        break;
      } catch (error) {
        lastError = error;
      }
    }
    if (!child) {
      this.retryAt = Date.now() + RETRY_DELAY_MS;
      const reason = lastError instanceof Error ? lastError.message : String(lastError);
      this.logFailure(`PresentMon could not start: ${reason}`);
      return;
    }
    this.child = child;
    this.samples = [];
    this.header = [];
    const generation = ++this.generation;
    void readLines2(child.stdout, (line) => this.consumeCsv(line, generation)).catch((error) => this.logFailure(`PresentMon output failed: ${error instanceof Error ? error.message : String(error)}`));
    void readLines2(child.stderr, (line) => {
      if (/\berror:/i.test(line)) this.logFailure(line.trim());
    }).catch(() => void 0);
    void child.status.then((status) => {
      if (generation !== this.generation) return;
      this.child = null;
      this.retryAt = Date.now() + RETRY_DELAY_MS;
      if (!status.success) this.logFailure(`PresentMon exited with code ${status.code}`);
    }).catch((error) => {
      if (generation !== this.generation) return;
      this.child = null;
      this.retryAt = Date.now() + RETRY_DELAY_MS;
      this.logFailure(`PresentMon failed: ${error instanceof Error ? error.message : String(error)}`);
    });
    this.log.info(`Native FPS capture started for ${target}`);
  }
  consumeCsv(line, generation) {
    if (generation !== this.generation || !line.trim()) return;
    const fields = parseCsvRow(line);
    if (fields[0] === "Application") {
      this.header = fields;
      return;
    }
    if (!this.header.length) return;
    const swapChainIndex = this.header.indexOf("SwapChainAddress");
    const frameTimeIndex = this.header.indexOf("msBetweenPresents");
    if (swapChainIndex < 0 || frameTimeIndex < 0) return;
    const frameTimeMs = Number(fields[frameTimeIndex]);
    if (!Number.isFinite(frameTimeMs) || frameTimeMs < 0.1 || frameTimeMs > 1e3) return;
    if (this.failureReported) {
      this.failureReported = false;
      this.log.info(`Native FPS capture recovered for ${this.target}`);
    }
    this.samples.push({
      receivedAt: Date.now(),
      swapChain: fields[swapChainIndex] || "default",
      frameTimeMs
    });
    if (this.samples.length > 1e4) this.samples.splice(0, this.samples.length - 1e4);
  }
  stopCapture() {
    const child = this.child;
    this.child = null;
    this.samples = [];
    this.header = [];
    this.generation += 1;
    if (!child) return;
    try {
      child.kill("SIGTERM");
    } catch {
    }
  }
  logFailure(message) {
    if (this.failureReported) return;
    this.failureReported = true;
    this.log.warn(message);
  }
};

// extension/storage.ts
var DRIVE_FIXED = 3;
var DRIVE_BUFFER_BYTES = 4096;
var GIB3 = 1024 ** 3;
var kernel324;
function runtime8() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function utf164(value2) {
  const bytes = new Uint8Array((value2.length + 1) * 2);
  const view = new DataView(bytes.buffer);
  for (let index = 0; index < value2.length; index += 1) view.setUint16(index * 2, value2.charCodeAt(index), true);
  return bytes;
}
function kernel3() {
  if (kernel324 !== void 0) return kernel324;
  const deno = runtime8();
  if (!deno) return kernel324 = null;
  try {
    kernel324 = deno.dlopen("kernel32.dll", {
      GetLogicalDriveStringsW: { parameters: ["u32", "buffer"], result: "u32" },
      GetDriveTypeW: { parameters: ["buffer"], result: "u32" },
      GetDiskFreeSpaceExW: { parameters: ["buffer", "buffer", "buffer", "buffer"], result: "u8" }
    });
  } catch {
    kernel324 = null;
  }
  return kernel324;
}
function driveRoots(api5) {
  const buffer = new Uint8Array(DRIVE_BUFFER_BYTES);
  const written = api5.symbols.GetLogicalDriveStringsW(buffer.byteLength / 2, buffer);
  if (!written || written >= buffer.byteLength / 2) return [];
  const names = new TextDecoder("utf-16le").decode(buffer.subarray(0, written * 2));
  return names.split("\0").filter(Boolean);
}
function size(api5, root) {
  const available = new Uint8Array(8);
  const total = new Uint8Array(8);
  const free = new Uint8Array(8);
  if (!api5.symbols.GetDiskFreeSpaceExW(utf164(root), available, total, free)) return null;
  const totalBytes = new DataView(total.buffer).getBigUint64(0, true);
  const freeBytes = new DataView(free.buffer).getBigUint64(0, true);
  if (totalBytes <= 0n || freeBytes > totalBytes) return null;
  return { totalBytes, freeBytes };
}
function readFixedDriveSpace() {
  try {
    const api5 = kernel3();
    if (!api5) return null;
    let totalBytes = 0n;
    let freeBytes = 0n;
    for (const root of driveRoots(api5)) {
      if (api5.symbols.GetDriveTypeW(utf164(root)) !== DRIVE_FIXED) continue;
      const result = size(api5, root);
      if (!result) continue;
      totalBytes += result.totalBytes;
      freeBytes += result.freeBytes;
    }
    if (!totalBytes) return null;
    const totalGb = Number(totalBytes) / GIB3;
    const freeGb = Number(freeBytes) / GIB3;
    return { totalGb, freeGb, usedGb: totalGb - freeGb };
  } catch {
    return null;
  }
}

// extension/windows-gpu.ts
var PDH_SUCCESS2 = 0;
var PDH_MORE_DATA2 = 2147485650;
var PDH_FMT_DOUBLE2 = 512;
var COUNTER_VALUE_ITEM_BYTES_642 = 24;
var COUNTER_VALUE_OFFSET_642 = 16;
var GIB4 = 1024 ** 3;
var pdh2;
var counters2;
function runtime9() {
  const candidate = globalThis.Deno;
  if (!candidate || candidate.build.os !== "windows") return null;
  return candidate.build.arch === "x86_64" || candidate.build.arch === "aarch64" ? candidate : null;
}
function utf165(value2) {
  const bytes = new Uint8Array((value2.length + 1) * 2);
  const view = new DataView(bytes.buffer);
  for (let index = 0; index < value2.length; index += 1) view.setUint16(index * 2, value2.charCodeAt(index), true);
  return bytes;
}
function api4() {
  if (pdh2 !== void 0) return pdh2;
  const deno = runtime9();
  if (!deno) return pdh2 = null;
  try {
    pdh2 = deno.dlopen("pdh.dll", {
      PdhOpenQueryW: { parameters: ["pointer", "u64", "buffer"], result: "u32" },
      PdhAddEnglishCounterW: { parameters: ["pointer", "buffer", "u64", "buffer"], result: "u32" },
      PdhCollectQueryData: { parameters: ["pointer"], result: "u32" },
      PdhGetFormattedCounterArrayW: { parameters: ["pointer", "u32", "buffer", "buffer", "pointer"], result: "u32" },
      PdhCloseQuery: { parameters: ["pointer"], result: "u32" }
    });
  } catch {
    pdh2 = null;
  }
  return pdh2;
}
function pointer2(runtime11, buffer) {
  const value2 = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength).getBigUint64(0, true);
  return value2 ? runtime11.UnsafePointer.create(value2) : null;
}
function addCounter2(runtime11, api5, query, path) {
  const output = new Uint8Array(8);
  if (api5.symbols.PdhAddEnglishCounterW(query, utf165(path), 0n, output) !== PDH_SUCCESS2) return null;
  return pointer2(runtime11, output);
}
function openCounters2() {
  if (counters2 !== void 0) return counters2;
  const deno = runtime9();
  const library = api4();
  if (!deno || !library) return counters2 = null;
  try {
    const output = new Uint8Array(8);
    if (library.symbols.PdhOpenQueryW(null, 0n, output) !== PDH_SUCCESS2) return counters2 = null;
    const query = pointer2(deno, output);
    if (!query) return counters2 = null;
    const usage = addCounter2(deno, library, query, "\\GPU Engine(*)\\Utilization Percentage");
    const dedicated = addCounter2(deno, library, query, "\\GPU Adapter Memory(*)\\Dedicated Usage");
    if (!usage || !dedicated) {
      library.symbols.PdhCloseQuery(query);
      return counters2 = null;
    }
    library.symbols.PdhCollectQueryData(query);
    return counters2 = { query, usage, dedicated };
  } catch {
    return counters2 = null;
  }
}
function values(deno, library, counter) {
  const size2 = new Uint8Array(4);
  const count = new Uint8Array(4);
  const first = library.symbols.PdhGetFormattedCounterArrayW(counter, PDH_FMT_DOUBLE2, size2, count, null);
  if (first !== PDH_MORE_DATA2 && first !== PDH_SUCCESS2) return [];
  const bytes = new DataView(size2.buffer).getUint32(0, true);
  const entries = new DataView(count.buffer).getUint32(0, true);
  if (!bytes || !entries || bytes < entries * COUNTER_VALUE_ITEM_BYTES_642) return [];
  const output = new Uint8Array(bytes);
  if (library.symbols.PdhGetFormattedCounterArrayW(counter, PDH_FMT_DOUBLE2, size2, count, deno.UnsafePointer.of(output)) !== PDH_SUCCESS2) return [];
  const result = [];
  const view = new DataView(output.buffer, output.byteOffset, output.byteLength);
  const actual = new DataView(count.buffer).getUint32(0, true);
  for (let index = 0; index < actual; index += 1) {
    const offset = index * COUNTER_VALUE_ITEM_BYTES_642 + COUNTER_VALUE_OFFSET_642;
    if (offset + 8 > view.byteLength) break;
    const value2 = view.getFloat64(offset, true);
    if (Number.isFinite(value2) && value2 >= 0) result.push(value2);
  }
  return result;
}
function readWindowsGpuMetrics() {
  try {
    const deno = runtime9();
    const library = api4();
    const active = openCounters2();
    if (!deno || !library || !active || library.symbols.PdhCollectQueryData(active.query) !== PDH_SUCCESS2) return null;
    const usageValues = values(deno, library, active.usage);
    const dedicatedValues = values(deno, library, active.dedicated);
    return {
      // Task Manager likewise treats the busiest GPU engine as the overall
      // utilization, rather than adding simultaneous engines past 100%.
      usagePercent: usageValues.length ? Math.min(100, Math.max(...usageValues)) : null,
      vramUsedGb: dedicatedValues.length ? dedicatedValues.reduce((sum, value2) => sum + value2, 0) / GIB4 : null
    };
  } catch {
    return null;
  }
}

// extension/windows-console.ts
function detachBridgeThingConsole() {
  const deno = globalThis.Deno;
  if (!deno || deno.build.os !== "windows") return;
  try {
    const kernel325 = deno.dlopen("kernel32.dll", {
      FreeConsole: { parameters: [], result: "i32" }
    });
    try {
      kernel325.symbols.FreeConsole();
    } finally {
      kernel325.close();
    }
  } catch {
  }
}

// extension/media-volume.ts
var decoder2 = new TextDecoder();
function runtime10() {
  const candidate = globalThis.Deno;
  return candidate && candidate.build.os === "windows" ? candidate : null;
}
function windowsPath2(url) {
  const decoded = decodeURIComponent(url.pathname).replace(/^\/([A-Za-z]:)/, "$1");
  return decoded.replace(/\//g, "\\");
}
function executableCandidates2() {
  return [
    windowsPath2(new URL("./vendor/media-host/BrutalDashMediaHost.exe", import.meta.url)),
    windowsPath2(new URL("../vendor/media-host/BrutalDashMediaHost.exe", import.meta.url)),
    windowsPath2(new URL("../public/vendor/media-host/BrutalDashMediaHost.exe", import.meta.url))
  ];
}
function unavailable(error) {
  return { ok: false, error, process: null, volume: null };
}
function parseResult(stdout) {
  try {
    const parsed = JSON.parse(decoder2.decode(stdout));
    if (typeof parsed.ok !== "boolean") return null;
    return {
      ok: parsed.ok,
      error: typeof parsed.error === "string" ? parsed.error : null,
      process: typeof parsed.process === "string" ? parsed.process : null,
      volume: typeof parsed.volume === "number" && Number.isFinite(parsed.volume) ? parsed.volume : null
    };
  } catch {
    return null;
  }
}
async function invoke(args) {
  const deno = runtime10();
  if (!deno) return null;
  for (const executable of executableCandidates2()) {
    try {
      const result = await new deno.Command(executable, { args, stdout: "piped", stderr: "piped" }).output();
      return { output: result.stdout, code: result.code, error: decoder2.decode(result.stderr).trim() };
    } catch {
    }
  }
  return null;
}
async function readWindowsMediaSnapshot(includeArtwork = false) {
  const result = await invoke(includeArtwork ? ["--snapshot", "--artwork"] : ["--snapshot"]);
  if (!result) return { ok: false, error: "Windows media helper is unavailable", source: null, title: null, artist: null, album: null, playback: null, positionMs: 0, durationMs: 0, artwork: null };
  try {
    const parsed = JSON.parse(decoder2.decode(result.output));
    return parsed;
  } catch {
    return { ok: false, error: result.error || `Windows media helper exited with code ${result.code}`, source: null, title: null, artist: null, album: null, playback: null, positionMs: 0, durationMs: 0, artwork: null };
  }
}
async function sendWindowsMediaCommand(command) {
  const result = await invoke(["--command", command]);
  if (!result) return false;
  try {
    return Boolean(JSON.parse(decoder2.decode(result.output)).ok);
  } catch {
    return false;
  }
}
async function adjustActiveMediaVolume(delta2, sourceHint) {
  const hint = sourceHint?.trim().slice(0, 120) || "";
  if (!runtime10()) return unavailable("Windows media volume is unavailable");
  if (!hint) return unavailable("No active media source");
  if (!Number.isFinite(delta2) || delta2 === 0) return unavailable("Invalid media volume request");
  const boundedDelta = Math.max(-0.2, Math.min(0.2, delta2));
  let lastError = "Windows media helper is unavailable";
  const output = await invoke(["--hint", hint, "--delta", String(boundedDelta)]);
  if (output) {
    const parsed = parseResult(output.output);
    if (parsed) return parsed;
    lastError = output.error || `Windows media helper exited with code ${output.code}`;
  }
  return unavailable(lastError);
}

// src/types.ts
var emptyLayoutSlots = () => [null, null, null, null];
function cloneLayoutSlots(slots) {
  return emptyLayoutSlots().map((_, index) => {
    const slot = slots?.[index];
    return slot ? { ...slot, layout: slot.layout.map((item) => ({ ...item, details: [...item.details] })) } : null;
  });
}
var metricKeys = [
  "gpuUsage",
  "gpuTemp",
  "gpuHotspot",
  "gpuClock",
  "gpuPower",
  "cpuUsage",
  "cpuTemp",
  "cpuClock",
  "cpuPower",
  "ramUsed",
  "ramPercent",
  "vramUsed",
  "vramPercent",
  "storageUsed",
  "storagePercent",
  "storageFree",
  "storageRead",
  "storageWrite",
  "networkDown",
  "networkUp",
  "fps",
  "frameTime",
  "onePercentLow"
];
var card = (id, metric, x, y, w, h, details, page) => ({ id, metric, details, x, y, w, h, hidden: false, page });
var presetLayouts = {
  four: [
    card("gpu", "gpuUsage", 0, 0, 3, 2, ["gpuTemp", "gpuPower", "vramUsed"]),
    card("cpu", "cpuUsage", 3, 0, 3, 2, ["cpuTemp", "cpuClock", "cpuPower"]),
    card("ram", "ramUsed", 0, 2, 3, 2, ["ramPercent"]),
    card("vram", "vramUsed", 3, 2, 3, 2, ["vramPercent", "gpuUsage"])
  ],
  rows: [
    card("gpu", "gpuUsage", 0, 0, 6, 1, ["gpuTemp", "gpuPower", "vramUsed"]),
    card("cpu", "cpuUsage", 0, 1, 6, 1, ["cpuTemp", "cpuClock", "cpuPower"]),
    card("ram", "ramUsed", 0, 2, 2, 2, ["ramPercent"]),
    card("storage", "storageRead", 2, 2, 2, 2, ["storageWrite", "storageUsed"]),
    card("network", "networkDown", 4, 2, 2, 2, ["networkUp"])
  ],
  list: [
    card("gpu", "gpuUsage", 0, 0, 6, 1, ["gpuTemp", "gpuPower", "vramUsed"]),
    card("cpu", "cpuUsage", 0, 1, 6, 1, ["cpuTemp", "cpuClock", "cpuPower"]),
    card("ram", "ramUsed", 0, 2, 6, 1, ["ramPercent"]),
    card("vram", "vramUsed", 0, 3, 6, 1, ["vramPercent", "gpuUsage"]),
    card("storage", "storageRead", 0, 4, 6, 1, ["storageWrite", "storageUsed"]),
    card("network", "networkDown", 0, 5, 6, 1, ["networkUp"])
  ],
  gaming: [
    card("fps", "fps", 0, 0, 4, 2, ["onePercentLow", "frameTime"]),
    card("gpu", "gpuUsage", 4, 0, 2, 2, ["gpuTemp", "gpuPower"]),
    card("cpu", "cpuUsage", 0, 2, 2, 2, ["cpuTemp", "cpuClock"]),
    card("vram", "vramUsed", 2, 2, 2, 2, ["vramPercent"]),
    card("ram", "ramUsed", 4, 2, 2, 2, ["ramPercent"])
  ],
  six: [
    card("gpu", "gpuUsage", 0, 0, 2, 2, ["gpuTemp", "gpuPower"]),
    card("cpu", "cpuUsage", 2, 0, 2, 2, ["cpuTemp", "cpuClock"]),
    card("ram", "ramUsed", 4, 0, 2, 2, ["ramPercent"]),
    card("vram", "vramUsed", 0, 2, 2, 2, ["vramPercent"]),
    card("storage", "storageRead", 2, 2, 2, 2, ["storageWrite", "storageUsed"]),
    card("network", "networkDown", 4, 2, 2, 2, ["networkUp"])
  ],
  paged: [
    card("gpu", "gpuUsage", 0, 0, 3, 4, ["gpuTemp", "gpuPower", "vramUsed"], 0),
    card("cpu", "cpuUsage", 3, 0, 3, 4, ["cpuTemp", "cpuClock", "cpuPower"], 0),
    card("ram", "ramUsed", 0, 0, 3, 4, ["ramPercent"], 1),
    card("vram", "vramUsed", 3, 0, 3, 4, ["vramPercent", "gpuUsage"], 1),
    card("storage", "storageRead", 0, 0, 3, 4, ["storageWrite", "storageUsed"], 2),
    card("network", "networkDown", 3, 0, 3, 4, ["networkUp"], 2)
  ]
};
function clonePresetLayout(preset) {
  return presetLayouts[preset].map((item) => ({ ...item, details: [...item.details] }));
}
var dashboardUiRevision = 6;
var defaultLayout = clonePresetLayout("four");
var defaultPreferences = {
  theme: "miami",
  accent: "#20f7e5",
  brightness: 100,
  glow: 70,
  compact: false,
  layoutPreset: "four",
  enabledMetrics: [...metricKeys],
  cpuAlert: 90,
  gpuAlert: 85,
  ramAlert: 92,
  clockMode: "automatic",
  clockFace: "foundry",
  clockFormat: "12",
  clockShowDate: true,
  clockColorMode: "theme",
  clockColor: "#20f7e5",
  gameInclude: [],
  gameExclude: []
};

// extension/main.ts
var POLL_INTERVAL_MS = 500;
var STORAGE_REFRESH_MS = 3e4;
var STATE_KEY_PREFIX = "dashboard-state:";
var metricRanges = /* @__PURE__ */ new Map();
var states = /* @__PURE__ */ new Map();
var latest = null;
var polling = false;
var timer;
var storageSpace = null;
var storageCheckedAt = 0;
var hwinfoAvailable = null;
var activePresentMonGroup = null;
var nativeFps = null;
var lastGame = null;
var lastMediaVolumeWarningAt = 0;
var mediaSubscribers = /* @__PURE__ */ new Set();
var mediaTimer;
var mediaPolling = false;
var mediaArtworkKey = "";
var mediaArtwork = null;
var mirrorClients = /* @__PURE__ */ new Set();
var mirrorServer = null;
var GAME_RETENTION_MS = 15e3;
detachBridgeThingConsole();
function mirrorBroadcast(message) {
  const body = JSON.stringify(message);
  for (const socket of mirrorClients) {
    if (socket.readyState !== WebSocket.OPEN) continue;
    try {
      socket.send(body);
    } catch {
      mirrorClients.delete(socket);
    }
  }
}
function primaryDeviceId(ctx) {
  return ctx.devices.find((device) => device.active)?.id ?? ctx.devices.find((device) => device.connected)?.id ?? states.keys().next().value;
}
function setMirrorControl(ctx, active) {
  for (const device of ctx.devices) {
    if (device.active) device.send(json({ type: "mirror:control", payload: { active } }));
  }
}
function sendMirrorSnapshot(ctx, socket) {
  const deviceId = primaryDeviceId(ctx);
  if (!deviceId) return;
  const state = states.get(deviceId);
  if (!state) return;
  socket.send(JSON.stringify({ type: "dashboard:state", payload: state }));
  socket.send(JSON.stringify({ type: "dashboard:data", payload: packetFor(state) }));
}
function startMirrorServer(ctx) {
  try {
    mirrorServer = Deno.serve({ hostname: "127.0.0.1", port: 8894, onListen() {
    } }, (request) => {
      if (request.headers.get("upgrade")?.toLowerCase() !== "websocket") {
        return Response.json({ ready: true, render: "desktop", videoFromDevice: false, audio: false });
      }
      const { socket, response } = Deno.upgradeWebSocket(request);
      socket.onopen = () => {
        mirrorClients.add(socket);
        setMirrorControl(ctx, true);
        sendMirrorSnapshot(ctx, socket);
      };
      socket.onmessage = (event) => {
        try {
          const message = JSON.parse(String(event.data));
          if (message.type === "dashboard:get") sendMirrorSnapshot(ctx, socket);
          if (message.type === "media:subscribe" && message.payload.active) void pollMedia(ctx);
        } catch {
          ctx.log.warn("Ignored malformed local recorder message");
        }
      };
      const remove = () => {
        mirrorClients.delete(socket);
        if (mirrorClients.size === 0) setMirrorControl(ctx, false);
      };
      socket.onclose = remove;
      socket.onerror = remove;
      return response;
    });
  } catch (error) {
    ctx.log.warn(`Local recording mirror unavailable: ${error instanceof Error ? error.message : String(error)}`);
  }
}
var finite = (value2) => typeof value2 === "number" && Number.isFinite(value2) ? value2 : null;
var reading = (value2, unit) => ({ value: value2, unit, min: null, max: null });
var empty = (unit) => reading(null, unit);
var themes = /* @__PURE__ */ new Set(["rog", "nvidia", "miami", "aurora", "synthwave", "arctic", "amber", "oled"]);
var layoutPresets = /* @__PURE__ */ new Set(["four", "rows", "list", "gaming", "six", "paged"]);
var clockModes = /* @__PURE__ */ new Set(["automatic", "dashboard", "clock"]);
var clockFaces = /* @__PURE__ */ new Set(["bold", "foundry", "minimal", "analog-foundry", "analog-minimal"]);
var clockFormats = /* @__PURE__ */ new Set(["12", "24"]);
var clockColorModes = /* @__PURE__ */ new Set(["theme", "custom"]);
function cloneLayout(layout) {
  return layout.map((item) => ({ ...item, details: [...item.details] }));
}
function clonePreferences(preferences) {
  return {
    ...defaultPreferences,
    ...preferences,
    enabledMetrics: [...preferences.enabledMetrics || defaultPreferences.enabledMetrics],
    gameInclude: [...preferences.gameInclude || []],
    gameExclude: [...preferences.gameExclude || []]
  };
}
function defaultState() {
  return { layout: cloneLayout(defaultLayout), preferences: clonePreferences(defaultPreferences), layoutSlots: cloneLayoutSlots(), uiRevision: dashboardUiRevision };
}
function stateKey(deviceId) {
  return `${STATE_KEY_PREFIX}${deviceId}`;
}
function clamp(value2, min, max) {
  return Math.min(max, Math.max(min, value2));
}
function validLayout(layout) {
  return Array.isArray(layout) && layout.every((item) => {
    if (!item || typeof item !== "object") return false;
    const candidate = item;
    return typeof candidate.id === "string" && metricKeys.includes(candidate.metric) && Array.isArray(candidate.details) && Number.isFinite(candidate.x) && Number.isFinite(candidate.y) && Number.isFinite(candidate.w) && Number.isFinite(candidate.h) && typeof candidate.hidden === "boolean";
  });
}
function validState(value2) {
  if (!value2 || typeof value2 !== "object") return null;
  const candidate = value2;
  if (!validLayout(candidate.layout) || !candidate.preferences || typeof candidate.preferences !== "object") return null;
  const preferences = candidate.preferences;
  if (!themes.has(preferences.theme) || !layoutPresets.has(preferences.layoutPreset)) return null;
  const processList = (input) => Array.isArray(input) ? [...new Set(input.filter((entry) => typeof entry === "string").map(normalizeProcessName2).filter(Boolean))].slice(0, 100) : [];
  const gameInclude = processList(preferences.gameInclude);
  return {
    layout: cloneLayout(candidate.layout),
    layoutSlots: cloneLayoutSlots(candidate.layoutSlots),
    preferences: {
      ...clonePreferences(defaultPreferences),
      ...preferences,
      enabledMetrics: Array.isArray(preferences.enabledMetrics) ? preferences.enabledMetrics.filter((metric) => metricKeys.includes(metric)) : [...metricKeys],
      clockMode: clockModes.has(preferences.clockMode || "") ? preferences.clockMode : defaultPreferences.clockMode,
      clockFace: clockFaces.has(preferences.clockFace || "") ? preferences.clockFace : defaultPreferences.clockFace,
      clockFormat: clockFormats.has(preferences.clockFormat || "") ? preferences.clockFormat : defaultPreferences.clockFormat,
      clockShowDate: typeof preferences.clockShowDate === "boolean" ? preferences.clockShowDate : defaultPreferences.clockShowDate,
      clockColorMode: clockColorModes.has(preferences.clockColorMode || "") ? preferences.clockColorMode : defaultPreferences.clockColorMode,
      clockColor: typeof preferences.clockColor === "string" && /^#[0-9a-f]{6}$/i.test(preferences.clockColor) ? preferences.clockColor : defaultPreferences.clockColor,
      gameInclude,
      gameExclude: processList(preferences.gameExclude).filter((entry) => !gameInclude.includes(entry))
    },
    uiRevision: dashboardUiRevision
  };
}
function stateFromConfig(state, config, changedKey) {
  if ((!changedKey || changedKey === "dashboardState") && config.dashboardState) {
    try {
      const restored = validState(JSON.parse(config.dashboardState));
      if (restored) return restored;
    } catch {
    }
  }
  if (!changedKey || changedKey === "dashboardState") return state;
  const preferences = clonePreferences(state.preferences);
  const raw = config[changedKey];
  if (raw === void 0) return state;
  if (changedKey === "theme" && themes.has(raw)) preferences.theme = raw;
  if (changedKey === "accent" && /^#[0-9a-f]{6}$/i.test(raw)) preferences.accent = raw;
  if (changedKey === "brightness") {
    const value2 = Number(raw);
    if (Number.isFinite(value2)) preferences.brightness = clamp(Math.round(value2), 35, 120);
  }
  if (changedKey === "glow") {
    const value2 = Number(raw);
    if (Number.isFinite(value2)) preferences.glow = clamp(Math.round(value2), 0, 100);
  }
  if (changedKey === "compact" && (raw === "true" || raw === "false")) preferences.compact = raw === "true";
  if (changedKey === "layoutPreset" && layoutPresets.has(raw)) {
    preferences.layoutPreset = raw;
    return { ...state, layout: clonePresetLayout(preferences.layoutPreset), preferences, uiRevision: dashboardUiRevision };
  }
  if (changedKey === "cpuAlert" || changedKey === "gpuAlert" || changedKey === "ramAlert") {
    const value2 = Number(raw);
    if (Number.isFinite(value2)) preferences[changedKey] = clamp(Math.round(value2), changedKey === "ramAlert" ? 50 : 60, changedKey === "ramAlert" ? 100 : 110);
  }
  return { ...state, preferences, uiRevision: dashboardUiRevision };
}
function sensorName(sensor) {
  return (sensor.nameDefault || sensor.nameCustom || "").trim();
}
function sensorParent(sensor) {
  return (sensor.parentNameDefault || sensor.parentNameCustom || "").trim();
}
function normalizeProcessName2(value2) {
  return value2.trim().split(/[\\/]/).pop()?.replace(/\.exe$/i, "").toLowerCase() || "";
}
function sensorCandidates(sensors, names, parent) {
  for (const name of names) {
    const matches = sensors.filter(
      (sensor) => sensorName(sensor).toLowerCase() === name.toLowerCase() && (!parent || parent.test(sensorParent(sensor))) && finite(sensor.valueNow) !== null
    );
    if (matches.length) return matches;
  }
  return [];
}
function sensorValues(sensors, names, parent) {
  return sensorCandidates(sensors, names, parent).map((sensor) => finite(sensor.valueNow)).filter((value2) => value2 !== null);
}
function sensorValue(sensors, names, parent, mode = "max") {
  const values2 = sensorValues(sensors, names, parent);
  if (!values2.length) return null;
  return mode === "sum" ? values2.reduce((total, value2) => total + value2, 0) : Math.max(...values2);
}
function sensorUnit(sensors, names, parent) {
  return sensorCandidates(sensors, names, parent)[0]?.unit.trim().toLowerCase() || "";
}
function memoryGb(sensors, names, parent) {
  const value2 = sensorValue(sensors, names, parent);
  if (value2 === null) return null;
  const unit = sensorUnit(sensors, names, parent);
  if (unit.includes("mb")) return value2 / 1024;
  if (unit.includes("gb")) return value2;
  return null;
}
function currentStorageSpace(now) {
  if (now - storageCheckedAt >= STORAGE_REFRESH_MS || storageCheckedAt === 0) {
    storageSpace = readFixedDriveSpace();
    storageCheckedAt = now;
  }
  return storageSpace;
}
function presentMonSensorsForProcess(sensors, processName) {
  if (!processName) {
    activePresentMonGroup = null;
    return [];
  }
  const fpsNames = ["Framerate Presented (avg)", "Framerate Displayed (avg)"];
  const groupKey = (sensor) => `${sensor.parentNameCustom}\0${sensor.parentNameDefault}`;
  const isPresentMon = (sensor) => /PresentMon(?:\s*\[[^\]]+\])?/i.test(`${sensor.parentNameCustom} ${sensor.parentNameDefault}`);
  const usable = (group) => {
    const value2 = sensorValue(group, fpsNames);
    return value2 !== null && value2 > 0;
  };
  const remember = (group) => {
    if (group.length) activePresentMonGroup = groupKey(group[0]);
    return group;
  };
  const available = sensors.filter(isPresentMon);
  const expected = normalizeProcessName2(processName || "");
  const processScoped = expected ? available.filter((sensor) => {
    const parent = `${sensor.parentNameCustom} ${sensor.parentNameDefault}`;
    const match = parent.match(/PresentMon\s*\[([^\]]+)\]/i);
    return normalizeProcessName2(match?.[1] || "") === expected;
  }) : [];
  if (usable(processScoped)) return remember(processScoped);
  const generic = available.filter((sensor) => /^PresentMon$/i.test(sensorParent(sensor)));
  if (usable(generic)) return remember(generic);
  if (activePresentMonGroup) {
    const previous2 = available.filter((sensor) => groupKey(sensor) === activePresentMonGroup);
    if (usable(previous2)) return previous2;
  }
  const groups = /* @__PURE__ */ new Map();
  for (const sensor of available) {
    const key = groupKey(sensor);
    const group = groups.get(key) || [];
    group.push(sensor);
    groups.set(key, group);
  }
  const active = [...groups.values()].filter(usable).sort((left, right) => (sensorValue(right, fpsNames) || 0) - (sensorValue(left, fpsNames) || 0))[0];
  return active ? remember(active) : [];
}
function gameFor(app, hasPresentMonReadings, preferences, now) {
  const label = detectedGame(app, hasPresentMonReadings, preferences);
  if (label && app) {
    lastGame = { label, processName: processFileName(app), seenAt: now };
    return lastGame;
  }
  if (lastGame && now - lastGame.seenAt <= GAME_RETENTION_MS) return lastGame;
  lastGame = null;
  return null;
}
function pollingPreferences(ctx) {
  for (const device of ctx.devices) {
    const state = states.get(device.id);
    if (device.active && state) return clonePreferences(state.preferences);
  }
  const preferences = states.values().next().value?.preferences;
  return preferences ? clonePreferences(preferences) : clonePreferences(defaultPreferences);
}
function parentHardwareName(sensors, kind) {
  const pattern = kind === "cpu" ? /CPU \[#\d+\]:\s*([^:]+)/i : /(?:dGPU|GPU) \[#\d+\]:\s*([^:]+)/i;
  for (const sensor of sensors) {
    const match = sensorParent(sensor).match(pattern);
    if (match?.[1]) return match[1].trim();
  }
  return kind === "cpu" ? "CPU" : "GPU";
}
function blankMetrics() {
  return {
    gpuUsage: empty("%"),
    gpuTemp: empty("\xB0C"),
    gpuHotspot: empty("\xB0C"),
    gpuClock: empty("MHz"),
    gpuPower: empty("W"),
    cpuUsage: empty("%"),
    cpuTemp: empty("\xB0C"),
    cpuClock: empty("MHz"),
    cpuPower: empty("W"),
    ramUsed: empty("GB"),
    ramPercent: empty("%"),
    vramUsed: empty("GB"),
    vramPercent: empty("%"),
    storageUsed: empty("GB"),
    storagePercent: empty("%"),
    storageFree: empty("GB"),
    storageRead: empty("MB/s"),
    storageWrite: empty("MB/s"),
    networkDown: empty("KB/s"),
    networkUp: empty("KB/s"),
    fps: empty("FPS"),
    frameTime: empty("ms"),
    onePercentLow: empty("FPS")
  };
}
function applyRanges(metrics) {
  for (const key of metricKeys) {
    const value2 = finite(metrics[key].value);
    const range = metricRanges.get(key);
    if (value2 !== null) {
      const next = range ? { min: Math.min(range.min, value2), max: Math.max(range.max, value2) } : { min: value2, max: value2 };
      metricRanges.set(key, next);
      metrics[key].min = next.min;
      metrics[key].max = next.max;
    } else if (range) {
      metrics[key].min = range.min;
      metrics[key].max = range.max;
    }
  }
}
function alerts(metrics, preferences) {
  const result = [];
  const temperature = (id, label, value2, threshold) => {
    if (value2 === null || value2 < threshold) return;
    result.push({ id, label, value: `${Math.round(value2)}\xB0C`, level: value2 >= threshold + 8 ? "critical" : "warning" });
  };
  temperature("cpu-temp", "CPU TEMP HIGH", metrics.cpuTemp.value, preferences.cpuAlert);
  temperature("gpu-temp", "GPU TEMP HIGH", metrics.gpuTemp.value, preferences.gpuAlert);
  const ram = metrics.ramPercent.value;
  if (ram !== null && ram >= preferences.ramAlert) {
    result.push({ id: "ram-usage", label: "RAM USAGE HIGH", value: `${Math.round(ram)}%`, level: ram >= 98 ? "critical" : "warning" });
  }
  return result;
}
function packetFor(state) {
  if (!latest) {
    return {
      timestamp: Date.now(),
      clock: new Intl.DateTimeFormat(void 0, { hour: "2-digit", minute: "2-digit" }).format(/* @__PURE__ */ new Date()),
      pcTimeOffsetMinutes: (/* @__PURE__ */ new Date()).getTimezoneOffset(),
      source: "native",
      fpsSource: null,
      connected: false,
      telemetryMessage: "Starting BrutalDash telemetry\u2026",
      cpuName: "Starting telemetry",
      gpuName: "Starting telemetry",
      game: null,
      foreground: null,
      capacities: { ramGb: null, vramGb: null, storageGb: null },
      metrics: blankMetrics(),
      alerts: []
    };
  }
  return { ...latest, alerts: latest.connected ? alerts(latest.metrics, state.preferences) : [] };
}
function readSensors() {
  const sensors = readHwInfoSharedMemory();
  if (!sensors.length) throw new Error("HWiNFO shared memory is unavailable");
  return sensors;
}
function nativeFallback(now, preferences) {
  const native = readNativeSystemMetrics();
  const storage = currentStorageSpace(now);
  const disk = readDiskIoRates();
  const network = readNetworkRates(now);
  const nvidia = readNvidiaGpuMetrics();
  const windowsGpu = readWindowsGpuMetrics();
  const foreground = readForegroundApp();
  nativeFps?.updateTarget(gameCandidate(foreground, preferences), now);
  const frames = nativeFps?.snapshot(now) || null;
  const game = gameFor(foreground, Boolean(frames), preferences, now);
  if (!native && !storage && !network) return null;
  const metrics = blankMetrics();
  const assign = (key, value2, unit = metrics[key].unit) => {
    if (value2 !== null) metrics[key] = reading(value2, unit);
  };
  assign("cpuUsage", native?.cpuPercent ?? null);
  assign("ramUsed", native?.ramUsedGb ?? null, "GB");
  assign("ramPercent", native?.ramPercent ?? null);
  assign("storageUsed", storage?.usedGb ?? null, "GB");
  assign("storageFree", storage?.freeGb ?? null, "GB");
  assign("storagePercent", storage ? storage.usedGb / storage.totalGb * 100 : null, "%");
  assign("storageRead", disk?.readMbPerSec ?? null, "MB/s");
  assign("storageWrite", disk?.writeMbPerSec ?? null, "MB/s");
  assign("networkDown", network?.downKbps ?? null, "KB/s");
  assign("networkUp", network?.upKbps ?? null, "KB/s");
  assign("gpuUsage", nvidia?.usagePercent ?? windowsGpu?.usagePercent ?? null);
  assign("gpuTemp", nvidia?.temperatureC ?? null, "\xB0C");
  assign("gpuClock", nvidia?.clockMhz ?? null, "MHz");
  assign("gpuPower", nvidia?.powerWatts ?? null, "W");
  assign("vramUsed", nvidia?.vramUsedGb ?? windowsGpu?.vramUsedGb ?? null, "GB");
  const nvidiaVramPercent = nvidia && nvidia.vramUsedGb !== null && nvidia.vramTotalGb !== null && nvidia.vramTotalGb > 0 ? nvidia.vramUsedGb / nvidia.vramTotalGb * 100 : null;
  assign("vramPercent", nvidiaVramPercent);
  assign("fps", frames?.fps ?? null, "FPS");
  assign("frameTime", frames?.frameTimeMs ?? null, "ms");
  assign("onePercentLow", frames?.onePercentLowFps ?? null, "FPS");
  applyRanges(metrics);
  return {
    timestamp: now,
    clock: new Intl.DateTimeFormat(void 0, { hour: "2-digit", minute: "2-digit" }).format(new Date(now)),
    pcTimeOffsetMinutes: new Date(now).getTimezoneOffset(),
    source: "native",
    fpsSource: frames ? "presentmon" : null,
    connected: true,
    telemetryMessage: "Using native telemetry. To switch to HWiNFO automatically, keep HWiNFO Sensors active (they may be minimized).",
    cpuName: readProcessorName() || "Windows system",
    gpuName: nvidia?.name || (windowsGpu ? "Windows GPU" : "GPU data unavailable"),
    game: game?.label || null,
    foreground: foregroundPacket(foreground),
    capacities: { ramGb: native?.ramTotalGb ?? null, vramGb: nvidia?.vramTotalGb ?? null, storageGb: storage?.totalGb ?? null },
    metrics
  };
}
async function poll(ctx) {
  if (polling) return;
  polling = true;
  const preferences = pollingPreferences(ctx);
  try {
    const now = Date.now();
    const sensors = readSensors();
    if (hwinfoAvailable === false) ctx.log.info("HWiNFO shared memory recovered");
    hwinfoAvailable = true;
    const cpu = /CPU \[#\d+\]/i;
    const gpu = /(dGPU|GPU \[#|NVIDIA|AMD Radeon|Intel Arc)/i;
    const metrics = blankMetrics();
    const assign = (key, value2, unit = metrics[key].unit) => {
      if (value2 !== null) metrics[key] = reading(value2, unit);
    };
    assign("cpuUsage", sensorValue(sensors, ["Total CPU Usage", "Total CPU Utility"], cpu));
    assign("cpuTemp", sensorValue(sensors, ["CPU Package", "Core Max"], cpu));
    assign("cpuClock", sensorValue(sensors, ["Core Effective Clocks", "P-core 0 Clock", "Core Clocks"], cpu));
    assign("cpuPower", sensorValue(sensors, ["CPU Package Power"], cpu));
    assign("gpuUsage", sensorValue(sensors, ["GPU Core Load", "GPU D3D Usage"], gpu));
    assign("gpuTemp", sensorValue(sensors, ["GPU Temperature"], gpu));
    assign("gpuHotspot", sensorValue(sensors, ["GPU Hot Spot Temperature", "GPU Hotspot Temperature"], gpu));
    assign("gpuClock", sensorValue(sensors, ["GPU Clock (measured)", "GPU Clock"], gpu));
    assign("gpuPower", sensorValue(sensors, ["GPU Power", "GPU ASIC Power", "GPU Board Power"], gpu));
    const ramUsedGb = memoryGb(sensors, ["Physical Memory Used"]);
    const ramAvailableGb = memoryGb(sensors, ["Physical Memory Available"]);
    assign("ramUsed", ramUsedGb, "GB");
    assign("ramPercent", sensorValue(sensors, ["Physical Memory Load"]));
    const vramNames = ["GPU Memory Allocated", "GPU D3D Memory Dedicated", "GPU Memory Usage"];
    const vramUsedGb = memoryGb(sensors, vramNames, gpu);
    const vramAvailableGb = memoryGb(sensors, ["GPU Memory Available"], gpu);
    assign("vramUsed", vramUsedGb, "GB");
    assign("vramPercent", vramUsedGb !== null && vramAvailableGb !== null ? vramUsedGb / (vramUsedGb + vramAvailableGb) * 100 : null);
    assign("storageRead", sensorValue(sensors, ["Read Rate"], /^Drive:/i, "sum"));
    assign("storageWrite", sensorValue(sensors, ["Write Rate"], /^Drive:/i, "sum"));
    const storage = currentStorageSpace(now);
    assign("storageUsed", storage?.usedGb ?? null, "GB");
    assign("storageFree", storage?.freeGb ?? null, "GB");
    assign("storagePercent", storage ? storage.usedGb / storage.totalGb * 100 : null, "%");
    assign("networkDown", sensorValue(sensors, ["Current DL rate"], /^Network:/i, "sum"));
    assign("networkUp", sensorValue(sensors, ["Current UP rate"], /^Network:/i, "sum"));
    const native = readNativeSystemMetrics();
    const network = readNetworkRates(now);
    const disk = readDiskIoRates();
    const nvidia = readNvidiaGpuMetrics();
    const windowsGpu = readWindowsGpuMetrics();
    let usedNativeFallback = false;
    const fill = (key, value2, unit = metrics[key].unit) => {
      if (metrics[key].value === null && value2 !== null) {
        metrics[key] = reading(value2, unit);
        usedNativeFallback = true;
      }
    };
    fill("cpuUsage", native?.cpuPercent ?? null);
    fill("ramUsed", native?.ramUsedGb ?? null, "GB");
    fill("ramPercent", native?.ramPercent ?? null);
    fill("networkDown", network?.downKbps ?? null, "KB/s");
    fill("networkUp", network?.upKbps ?? null, "KB/s");
    fill("storageRead", disk?.readMbPerSec ?? null, "MB/s");
    fill("storageWrite", disk?.writeMbPerSec ?? null, "MB/s");
    fill("gpuUsage", nvidia?.usagePercent ?? windowsGpu?.usagePercent ?? null);
    fill("gpuTemp", nvidia?.temperatureC ?? null, "\xB0C");
    fill("gpuClock", nvidia?.clockMhz ?? null, "MHz");
    fill("gpuPower", nvidia?.powerWatts ?? null, "W");
    fill("vramUsed", nvidia?.vramUsedGb ?? windowsGpu?.vramUsedGb ?? null, "GB");
    const fallbackVramPercent = nvidia && nvidia.vramUsedGb !== null && nvidia.vramTotalGb !== null && nvidia.vramTotalGb > 0 ? nvidia.vramUsedGb / nvidia.vramTotalGb * 100 : null;
    fill("vramPercent", fallbackVramPercent);
    const foreground = readForegroundApp();
    const fpsTarget = fpsCaptureTarget(foreground, preferences, lastGame, now, GAME_RETENTION_MS);
    const presentMonSensors = presentMonSensorsForProcess(sensors, fpsTarget.sensorProcessName);
    assign("fps", sensorValue(presentMonSensors, ["Framerate Presented (avg)", "Framerate Displayed (avg)"]), "FPS");
    assign("frameTime", sensorValue(presentMonSensors, ["Frame Time Presented (avg)", "Frame Time Displayed (avg)"]), "ms");
    assign("onePercentLow", sensorValue(presentMonSensors, ["Framerate Presented (1% low)", "Framerate Displayed (1% low)"]), "FPS");
    nativeFps?.updateTarget(fpsTarget.liveProcessName, now);
    const frames = nativeFps?.snapshot(now) || null;
    const game = gameFor(foreground, presentMonSensors.length > 0 || Boolean(frames), preferences, now);
    if (frames) {
      metrics.fps = reading(frames.fps, "FPS");
      metrics.frameTime = reading(frames.frameTimeMs, "ms");
      metrics.onePercentLow = reading(frames.onePercentLowFps, "FPS");
      usedNativeFallback = true;
    }
    applyRanges(metrics);
    const hwCpuName = parentHardwareName(sensors, "cpu");
    const hwGpuName = parentHardwareName(sensors, "gpu");
    latest = {
      timestamp: now,
      clock: new Intl.DateTimeFormat(void 0, { hour: "2-digit", minute: "2-digit" }).format(new Date(now)),
      pcTimeOffsetMinutes: new Date(now).getTimezoneOffset(),
      source: usedNativeFallback ? "hybrid" : "hwinfo",
      fpsSource: frames ? "presentmon" : metrics.fps.value === null ? null : "hwinfo",
      connected: true,
      telemetryMessage: null,
      cpuName: hwCpuName !== "CPU" ? hwCpuName : readProcessorName() || "Windows system",
      gpuName: hwGpuName !== "GPU" ? hwGpuName : nvidia?.name || (windowsGpu ? "Windows GPU" : "GPU"),
      game: game?.label || null,
      foreground: foregroundPacket(foreground),
      capacities: {
        ramGb: ramUsedGb !== null && ramAvailableGb !== null ? ramUsedGb + ramAvailableGb : native?.ramTotalGb ?? null,
        vramGb: vramUsedGb !== null && vramAvailableGb !== null ? vramUsedGb + vramAvailableGb : nvidia?.vramTotalGb ?? null,
        storageGb: storage?.totalGb ?? null
      },
      metrics
    };
    for (const device of ctx.devices) {
      const state = states.get(device.id);
      if (device.active && state) device.send(json({ type: "dashboard:data", payload: packetFor(state) }));
    }
    const mirrorDeviceId = primaryDeviceId(ctx);
    const mirrorState = mirrorDeviceId ? states.get(mirrorDeviceId) : null;
    if (mirrorState) mirrorBroadcast({ type: "dashboard:data", payload: packetFor(mirrorState) });
  } catch (error) {
    if (hwinfoAvailable !== false) ctx.log.warn(`HWiNFO shared memory unavailable: ${error instanceof Error ? error.message : String(error)}`);
    hwinfoAvailable = false;
    try {
      const fallback = nativeFallback(Date.now(), preferences);
      if (fallback) {
        latest = fallback;
        for (const device of ctx.devices) {
          const state = states.get(device.id);
          if (device.active && state) device.send(json({ type: "dashboard:data", payload: packetFor(state) }));
        }
        const mirrorDeviceId = primaryDeviceId(ctx);
        const mirrorState = mirrorDeviceId ? states.get(mirrorDeviceId) : null;
        if (mirrorState) mirrorBroadcast({ type: "dashboard:data", payload: packetFor(mirrorState) });
      } else {
        latest = latest ? { ...latest, connected: false } : null;
      }
    } catch (fallbackError) {
      ctx.log.error(`Native telemetry fallback failed: ${fallbackError instanceof Error ? fallbackError.message : String(fallbackError)}`);
      latest = latest ? { ...latest, connected: false } : null;
    }
  } finally {
    polling = false;
  }
}
async function loadState(ctx, deviceId) {
  const saved = await ctx.kv.get(stateKey(deviceId));
  const state = validState(saved) || defaultState();
  const configured = stateFromConfig(state, ctx.config(deviceId));
  states.set(deviceId, configured);
  return configured;
}
async function sendState(ctx, deviceId) {
  const device = ctx.device(deviceId);
  const state = states.get(deviceId) || await loadState(ctx, deviceId);
  device.send(json({ type: "dashboard:state", payload: state }));
  device.send(json({ type: "dashboard:data", payload: packetFor(state) }));
  if (deviceId === primaryDeviceId(ctx)) {
    mirrorBroadcast({ type: "dashboard:state", payload: state });
    mirrorBroadcast({ type: "dashboard:data", payload: packetFor(state) });
  }
}
async function pollMedia(ctx) {
  if (mediaPolling || mediaSubscribers.size === 0) return;
  mediaPolling = true;
  try {
    let snapshot2 = await readWindowsMediaSnapshot(false);
    const artworkKey = snapshot2.ok ? `${snapshot2.source || ""}
${snapshot2.title || ""}
${snapshot2.artist || ""}` : "";
    if (artworkKey && artworkKey !== mediaArtworkKey) {
      for (const deviceId of mediaSubscribers) {
        const device = ctx.device(deviceId);
        if (device.active) device.send(json({ type: "media:data", payload: snapshot2 }));
      }
      mirrorBroadcast({ type: "media:data", payload: snapshot2 });
      const withArtwork = await readWindowsMediaSnapshot(true);
      if (withArtwork.ok) snapshot2 = withArtwork;
      mediaArtworkKey = artworkKey;
      mediaArtwork = snapshot2.artwork;
    } else if (artworkKey === mediaArtworkKey) {
      snapshot2 = { ...snapshot2, artwork: mediaArtwork };
    } else {
      mediaArtworkKey = "";
      mediaArtwork = null;
    }
    for (const deviceId of mediaSubscribers) {
      const device = ctx.device(deviceId);
      if (device.active) device.send(json({ type: "media:data", payload: snapshot2 }));
    }
    mirrorBroadcast({ type: "media:data", payload: snapshot2 });
  } finally {
    mediaPolling = false;
  }
}
defineExtension({
  start(ctx) {
    startMirrorServer(ctx);
    nativeFps = new PresentMonProvider({
      info: (message) => ctx.log.info(message),
      warn: (message) => ctx.log.warn(message)
    });
    ctx.on("device", (event) => {
      if (event.type === "connected" || event.type === "active" && event.device.active) {
        void sendState(ctx, event.device.id).catch((error) => ctx.log.error("state send failed", error));
        if (mirrorClients.size > 0 && event.device.active) {
          event.device.send(json({ type: "mirror:control", payload: { active: true } }));
        }
      }
    });
    ctx.on("message", (device, message) => {
      const payload = asJson(message);
      if (!payload) return;
      if (payload.type === "mirror:input") {
        if (mirrorClients.size > 0) mirrorBroadcast(payload);
        return;
      }
      if (payload.type === "media:command") {
        void sendWindowsMediaCommand(payload.payload.command).then((ok) => {
          if (!ok) ctx.log.warn("Windows media control unavailable");
          void pollMedia(ctx);
        });
        return;
      }
      if (payload.type === "media:subscribe") {
        if (payload.payload.active) mediaSubscribers.add(device.id);
        else mediaSubscribers.delete(device.id);
        if (payload.payload.active) void pollMedia(ctx);
        return;
      }
      if (payload.type === "media:volume") {
        void adjustActiveMediaVolume(payload.payload.delta, payload.payload.source).then((result) => {
          if (!result.ok && Date.now() - lastMediaVolumeWarningAt > 5e3) {
            lastMediaVolumeWarningAt = Date.now();
            ctx.log.warn(`PC media volume unavailable: ${result.error || "no matching media session"}`);
          }
        }).catch((error) => ctx.log.warn(`PC media volume failed: ${error instanceof Error ? error.message : String(error)}`));
        return;
      }
      if (payload.type === "dashboard:get") void sendState(ctx, device.id).catch((error) => ctx.log.error("dashboard request failed", error));
      if (payload.type === "dashboard:save" && payload.payload && Array.isArray(payload.payload.layout) && payload.payload.preferences) {
        states.set(device.id, payload.payload);
        void ctx.kv.set(stateKey(device.id), payload.payload).then(() => sendState(ctx, device.id)).catch((error) => ctx.log.error("dashboard save failed", error));
      }
    });
    ctx.on("config", (device, key, value2) => {
      const state = states.get(device.id) || defaultState();
      const config = { ...ctx.config(device) };
      if (value2 === null) delete config[key];
      else config[key] = value2;
      const next = stateFromConfig(state, config, key);
      states.set(device.id, next);
      void ctx.kv.set(stateKey(device.id), next).then(() => sendState(ctx, device.id)).catch((error) => ctx.log.error("dashboard setting save failed", error));
    });
    void poll(ctx);
    timer = setInterval(() => void poll(ctx), POLL_INTERVAL_MS);
    mediaTimer = setInterval(() => void pollMedia(ctx), 750);
    ctx.log.info(`BrutalDash bridge extension started with ${POLL_INTERVAL_MS}ms telemetry polling`);
  },
  stop() {
    clearInterval(timer);
    clearInterval(mediaTimer);
    mediaSubscribers.clear();
    nativeFps?.stop();
    nativeFps = null;
    for (const socket of mirrorClients) socket.close(1001, "BrutalDash extension stopping");
    mirrorClients.clear();
    void mirrorServer?.shutdown();
    mirrorServer = null;
  }
});
